package com.lone.materix

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
