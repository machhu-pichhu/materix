import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'users_record.g.dart';

abstract class UsersRecord implements Built<UsersRecord, UsersRecordBuilder> {
  static Serializer<UsersRecord> get serializer => _$usersRecordSerializer;

  String? get email;

  @BuiltValueField(wireName: 'display_name')
  String? get displayName;

  @BuiltValueField(wireName: 'photo_url')
  String? get photoUrl;

  String? get uid;

  @BuiltValueField(wireName: 'created_time')
  DateTime? get createdTime;

  @BuiltValueField(wireName: 'phone_number')
  String? get phoneNumber;

  String? get level;

  String? get course;

  String? get school;

  @BuiltValueField(wireName: 'my_skills')
  BuiltList<String>? get mySkills;

  int? get points;

  @BuiltValueField(wireName: 'jobs_completed')
  int? get jobsCompleted;

  @BuiltValueField(wireName: 'requests_completed')
  int? get requestsCompleted;

  String? get status;

  @BuiltValueField(wireName: 'my_main_skill')
  String? get myMainSkill;

  String? get role;

  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference? get ffRef;
  DocumentReference get reference => ffRef!;

  static void _initializeBuilder(UsersRecordBuilder builder) => builder
    ..email = ''
    ..displayName = ''
    ..photoUrl = ''
    ..uid = ''
    ..phoneNumber = ''
    ..level = ''
    ..course = ''
    ..school = ''
    ..mySkills = ListBuilder()
    ..points = 0
    ..jobsCompleted = 0
    ..requestsCompleted = 0
    ..status = ''
    ..myMainSkill = ''
    ..role = '';

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('users');

  static Stream<UsersRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  static Future<UsersRecord> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  UsersRecord._();
  factory UsersRecord([void Function(UsersRecordBuilder) updates]) =
      _$UsersRecord;

  static UsersRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference})!;
}

Map<String, dynamic> createUsersRecordData({
  String? email,
  String? displayName,
  String? photoUrl,
  String? uid,
  DateTime? createdTime,
  String? phoneNumber,
  String? level,
  String? course,
  String? school,
  int? points,
  int? jobsCompleted,
  int? requestsCompleted,
  String? status,
  String? myMainSkill,
  String? role,
}) {
  final firestoreData = serializers.toFirestore(
    UsersRecord.serializer,
    UsersRecord(
      (u) => u
        ..email = email
        ..displayName = displayName
        ..photoUrl = photoUrl
        ..uid = uid
        ..createdTime = createdTime
        ..phoneNumber = phoneNumber
        ..level = level
        ..course = course
        ..school = school
        ..mySkills = null
        ..points = points
        ..jobsCompleted = jobsCompleted
        ..requestsCompleted = requestsCompleted
        ..status = status
        ..myMainSkill = myMainSkill
        ..role = role,
    ),
  );

  return firestoreData;
}
