// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'faq_record.dart';

// **************************************************************************
// BuiltValueGenerator
// **************************************************************************

Serializer<FaqRecord> _$faqRecordSerializer = new _$FaqRecordSerializer();

class _$FaqRecordSerializer implements StructuredSerializer<FaqRecord> {
  @override
  final Iterable<Type> types = const [FaqRecord, _$FaqRecord];
  @override
  final String wireName = 'FaqRecord';

  @override
  Iterable<Object?> serialize(Serializers serializers, FaqRecord object,
      {FullType specifiedType = FullType.unspecified}) {
    final result = <Object?>[];
    Object? value;
    value = object.name;
    if (value != null) {
      result
        ..add('name')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.text;
    if (value != null) {
      result
        ..add('text')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.ffRef;
    if (value != null) {
      result
        ..add('Document__Reference__Field')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(
                DocumentReference, const [const FullType.nullable(Object)])));
    }
    return result;
  }

  @override
  FaqRecord deserialize(Serializers serializers, Iterable<Object?> serialized,
      {FullType specifiedType = FullType.unspecified}) {
    final result = new FaqRecordBuilder();

    final iterator = serialized.iterator;
    while (iterator.moveNext()) {
      final key = iterator.current! as String;
      iterator.moveNext();
      final Object? value = iterator.current;
      switch (key) {
        case 'name':
          result.name = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'text':
          result.text = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'Document__Reference__Field':
          result.ffRef = serializers.deserialize(value,
              specifiedType: const FullType(DocumentReference, const [
                const FullType.nullable(Object)
              ])) as DocumentReference<Object?>?;
          break;
      }
    }

    return result.build();
  }
}

class _$FaqRecord extends FaqRecord {
  @override
  final String? name;
  @override
  final String? text;
  @override
  final DocumentReference<Object?>? ffRef;

  factory _$FaqRecord([void Function(FaqRecordBuilder)? updates]) =>
      (new FaqRecordBuilder()..update(updates))._build();

  _$FaqRecord._({this.name, this.text, this.ffRef}) : super._();

  @override
  FaqRecord rebuild(void Function(FaqRecordBuilder) updates) =>
      (toBuilder()..update(updates)).build();

  @override
  FaqRecordBuilder toBuilder() => new FaqRecordBuilder()..replace(this);

  @override
  bool operator ==(Object other) {
    if (identical(other, this)) return true;
    return other is FaqRecord &&
        name == other.name &&
        text == other.text &&
        ffRef == other.ffRef;
  }

  @override
  int get hashCode {
    var _$hash = 0;
    _$hash = $jc(_$hash, name.hashCode);
    _$hash = $jc(_$hash, text.hashCode);
    _$hash = $jc(_$hash, ffRef.hashCode);
    _$hash = $jf(_$hash);
    return _$hash;
  }

  @override
  String toString() {
    return (newBuiltValueToStringHelper(r'FaqRecord')
          ..add('name', name)
          ..add('text', text)
          ..add('ffRef', ffRef))
        .toString();
  }
}

class FaqRecordBuilder implements Builder<FaqRecord, FaqRecordBuilder> {
  _$FaqRecord? _$v;

  String? _name;
  String? get name => _$this._name;
  set name(String? name) => _$this._name = name;

  String? _text;
  String? get text => _$this._text;
  set text(String? text) => _$this._text = text;

  DocumentReference<Object?>? _ffRef;
  DocumentReference<Object?>? get ffRef => _$this._ffRef;
  set ffRef(DocumentReference<Object?>? ffRef) => _$this._ffRef = ffRef;

  FaqRecordBuilder() {
    FaqRecord._initializeBuilder(this);
  }

  FaqRecordBuilder get _$this {
    final $v = _$v;
    if ($v != null) {
      _name = $v.name;
      _text = $v.text;
      _ffRef = $v.ffRef;
      _$v = null;
    }
    return this;
  }

  @override
  void replace(FaqRecord other) {
    ArgumentError.checkNotNull(other, 'other');
    _$v = other as _$FaqRecord;
  }

  @override
  void update(void Function(FaqRecordBuilder)? updates) {
    if (updates != null) updates(this);
  }

  @override
  FaqRecord build() => _build();

  _$FaqRecord _build() {
    final _$result =
        _$v ?? new _$FaqRecord._(name: name, text: text, ffRef: ffRef);
    replace(_$result);
    return _$result;
  }
}

// ignore_for_file: deprecated_member_use_from_same_package,type=lint
