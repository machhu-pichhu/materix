import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyBPVQT8CY6nbt9On7wDWUhfmxaE6TAmKGE",
            authDomain: "materix-5d083.firebaseapp.com",
            projectId: "materix-5d083",
            storageBucket: "materix-5d083.appspot.com",
            messagingSenderId: "459115792932",
            appId: "1:459115792932:web:a7022b788406ea23e6e6b1",
            measurementId: "G-DR89FRDXQN"));
  } else {
    await Firebase.initializeApp();
  }
}
